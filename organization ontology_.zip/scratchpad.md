# ADM Explorer — Deck Plan

## Audience & purpose
Internal/stakeholder pitch for ADM (Architecture Domain Model) Explorer.
Duration: 8–12 min, 10 slides. Tone: confident, technical-but-clear, minimal.

## Visual system
- Background: white #ffffff; contrast sections #f9fafb
- Text: #111827 (near-black), #6b7280 (secondary gray)
- Primary accent: #2563eb (blue)
- Entity-type colors (the ontology spine):
  - Domain   #2563eb  blue
  - Capability #7c3aed purple
  - Process  #059669  green
  - System   #d97706  amber
  - Technology #dc2626 red
  - (cyan #0891b2 reserved / spare)
- Type: Inter for headings + body; IBM Plex Mono for technical labels
  (entity types, relationship verbs, code-ish chips) — gives an
  "architecture repository" feel and contrasts cleanly.
- Animations: gentle fade-up for text (stagger), progressive left→right
  build for the chain motif, reverse-traversal build for impact. Driven by
  an `.is-active` class toggled on slidechange. No bounce/spin.

## Recurring motif
The ontology spine — Domain → Capability → Process → System → Technology —
appears on slides 4 (intro), 6 (full graph), 7 (impact, reversed).
Arrow verbs: owns · realized_by · supported_by · uses

## Title sequence (textbook noun-phrase style)
1. Architecture Domain Model Explorer        (title)
2. The Problem
3. Why This Matters Now
4. The Solution
5. Ask Questions in Plain Language
6. See the Full Picture
7. Understand Impact Before You Act
8. One Language, One Truth
9. Built for the AI Era
10. Architecture Domain Model Explorer       (close)

Reading titles top to bottom: problem → why now → solution → three
solution facets (NL query, graph, impact) → two value facets (ontology,
AI-ready) → close. Flows.

## Per-slide layout intent (avoid text walls)
1. Centered title, connected-graph mark, tagline. Whitespace-heavy.
2. Three columns (Scattered / Inconsistent / Invisible), geometric icons.
3. Two stacked rows (AI Enablement / Org Alignment) + centered pull quote.
4. Hero: the chain motif, big, with verb labels + one supporting sentence.
5. Product mockup — chat panel left, mini graph right; two example Q&As.
6. Full org graph mockup (multi-domain), three callouts beneath.
7. Reverse-traversal impact diagram fanning out from Java (red).
8. Two columns: Without ADM (tangled, grayed) vs With ADM (aligned).
9. Three rows: agents query it / any LLM / any data source. Mono bottom line.
10. Centered title + subtitle + 3 action lines + github footer.

## Type scale (px, 1920×1080)
--type-display 96 (title slides) / --type-title 60 / --type-headline 40
--type-body 30 / --type-small 26 / --type-label 24 (mono labels)
